/***************************************************************************
    copyright            : (C) 2014 by Urs Fleisch
    email                : ufleisch@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *   This library is free software; you can redistribute it and/or modify  *
 *   it  under the terms of the GNU Lesser General Public License version  *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful, but   *
 *   WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA         *
 *   02110-1301  USA                                                       *
 *                                                                         *
 *   Alternatively, this file is available under the Mozilla Public        *
 *   License Version 1.1.  You may obtain a copy of the License at         *
 *   http://www.mozilla.org/MPL/                                           *
 ***************************************************************************/

#include "eventtimingcodesframe.h"

#include <utility>

#include "tbytevectorlist.h"
#include "tdebug.h"
#include "id3v2tag.h"

using namespace TagLib;
using namespace ID3v2;

namespace
{
  /*!
   * Returns the timestamp format denoted by \a c, or Unknown if it denotes
   * nothing. The range of the enumeration is only 0..3, so the byte read from
   * the file cannot simply be cast.
   */
  EventTimingCodesFrame::TimestampFormat timestampFormatFromByte(char c)
  {
    if(const auto value = static_cast<unsigned char>(c);
       value <= EventTimingCodesFrame::AbsoluteMilliseconds)
      return static_cast<EventTimingCodesFrame::TimestampFormat>(value);

    return EventTimingCodesFrame::Unknown;
  }
} // namespace

class EventTimingCodesFrame::EventTimingCodesFramePrivate
{
public:
  EventTimingCodesFrame::TimestampFormat timestampFormat { EventTimingCodesFrame::AbsoluteMilliseconds };
  EventTimingCodesFrame::SynchedEventList synchedEvents;
};

////////////////////////////////////////////////////////////////////////////////
// public members
////////////////////////////////////////////////////////////////////////////////

EventTimingCodesFrame::EventTimingCodesFrame() :
  Frame("ETCO"),
  d(std::make_unique<EventTimingCodesFramePrivate>())
{
}

EventTimingCodesFrame::EventTimingCodesFrame(const ByteVector &data) :
  Frame(data),
  d(std::make_unique<EventTimingCodesFramePrivate>())
{
  setData(data);
}

EventTimingCodesFrame::~EventTimingCodesFrame() = default;

String EventTimingCodesFrame::toString() const
{
  return String();
}

EventTimingCodesFrame::TimestampFormat
EventTimingCodesFrame::timestampFormat() const
{
  return d->timestampFormat;
}

EventTimingCodesFrame::SynchedEventList
EventTimingCodesFrame::synchedEvents() const
{
  return d->synchedEvents;
}

void EventTimingCodesFrame::setTimestampFormat(
    EventTimingCodesFrame::TimestampFormat f)
{
  d->timestampFormat = f;
}

void EventTimingCodesFrame::setSynchedEvents(
    const EventTimingCodesFrame::SynchedEventList &e)
{
  d->synchedEvents = e;
}

////////////////////////////////////////////////////////////////////////////////
// protected members
////////////////////////////////////////////////////////////////////////////////

void EventTimingCodesFrame::parseFields(const ByteVector &data)
{
  const int end = data.size();
  if(end < 1) {
    debug("An event timing codes frame must contain at least 1 byte.");
    return;
  }

  d->timestampFormat = timestampFormatFromByte(data[0]);

  int pos = 1;
  d->synchedEvents.clear();
  while(pos + 4 < end) {
    auto type = static_cast<EventType>(static_cast<unsigned char>(data[pos++]));
    unsigned int time = data.toUInt(pos, true);
    pos += 4;
    d->synchedEvents.append(SynchedEvent(time, type));
  }
}

ByteVector EventTimingCodesFrame::renderFields() const
{
  ByteVector v;

  v.append(static_cast<char>(d->timestampFormat));
  for(const auto &entry : std::as_const(d->synchedEvents)) {
    v.append(static_cast<char>(entry.type));
    v.append(ByteVector::fromUInt(entry.time));
  }

  return v;
}

////////////////////////////////////////////////////////////////////////////////
// private members
////////////////////////////////////////////////////////////////////////////////

EventTimingCodesFrame::EventTimingCodesFrame(const ByteVector &data, Header *h) :
  Frame(h),
  d(std::make_unique<EventTimingCodesFramePrivate>())
{
  parseFields(fieldData(data));
}
